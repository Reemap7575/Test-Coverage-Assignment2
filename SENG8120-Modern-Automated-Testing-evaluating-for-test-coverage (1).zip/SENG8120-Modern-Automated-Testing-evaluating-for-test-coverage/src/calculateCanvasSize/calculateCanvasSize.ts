export default function calculateCanvasSize(
  length: string,
  width: string
) {
  return parseInt(length) * parseInt(width);
}
