import { calculateCanvasSize } from './src/calculateCanvasSize';
import { calculatePaintRequired } from './src/paintRequiredCalculator';

console.log('Canvas Size:', calculateCanvasSize(10, 5));
console.log('Paint Required:', calculatePaintRequired(20, 10));
