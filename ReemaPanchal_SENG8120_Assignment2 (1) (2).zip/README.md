# SENG8120 – Assignment 2: Test Coverage & TDD

## Overview
Test-driven improvements to canvas and paint calculators using TypeScript and Jest.

## Run Tests
```bash
npm install
npm test
```

## View Test Coverage
```bash
npm test -- --coverage
```

## Author
Reema Panchal – 8977575
