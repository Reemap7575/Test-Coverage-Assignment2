import { calculateCanvasSize } from './calculateCanvasSize';

test('valid dimensions', () => {
    expect(calculateCanvasSize(10, 5)).toBe(50);
});

test('invalid dimensions should throw error', () => {
    expect(() => calculateCanvasSize(0, 10)).toThrow("Invalid dimensions");
});
