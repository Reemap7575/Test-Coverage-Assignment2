export * from './paintRequiredCalculator';
