export function calculatePaintRequired(width: number, height: number): number {
    if (width <= 0 || height <= 0) throw new Error("Invalid input");
    const area = width * height;
    const coveragePerLitre = 10;
    return area / coveragePerLitre;
}
