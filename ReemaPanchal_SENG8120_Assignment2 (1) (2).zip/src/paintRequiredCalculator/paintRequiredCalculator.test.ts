import { calculatePaintRequired } from './paintRequiredCalculator';

test('calculates paint required correctly', () => {
    expect(calculatePaintRequired(20, 10)).toBe(20);
});

test('throws error for negative input', () => {
    expect(() => calculatePaintRequired(-5, 10)).toThrow("Invalid input");
});
