export default {
  preset: 'ts-jest',
  testEnvironment: 'node',
  collectCoverage: true,
  collectCoverageFrom: ['src/**/*.ts', '!**/*.test.ts'],
  coverageDirectory: 'coverage',
};
